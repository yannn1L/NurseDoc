/* ============================================================
   BLOCKS (WEB) — renderer Web View
============================================================ */
import { esc } from '../core/dom.js';

export const webBlocks = {
  /* ---------- COVER ---------- */
  cover: {
    validate: (b) => typeof b.judul === 'string',
    weight: () => 400,
    render: (b) => `
      <div class="py-12 text-center border-b border-slate-200 mb-8">
        ${b.header ? `<div class="text-[13px] font-semibold text-slate-700 uppercase tracking-wider leading-relaxed whitespace-pre-line mb-6">${esc(b.header)}</div>` : ''}
        ${b.category ? `<div class="inline-block px-4 py-1.5 bg-brand-600 text-white text-[11px] font-bold uppercase tracking-widest rounded-full mb-6">${esc(b.category)}</div>` : ''}
        <h1 class="text-[26px] font-bold text-slate-900 leading-tight max-w-2xl mx-auto mb-8">${esc(b.judul)}</h1>
        ${b.penyusun?.length ? `
          <div class="inline-block text-left bg-slate-50 border border-slate-200 rounded-xl px-6 py-4 mb-8">
            <div class="text-[10px] uppercase tracking-widest text-slate-400 font-bold text-center mb-3">Disusun oleh</div>
            ${b.penyusun.map(p => `
              <div class="flex gap-3 text-[12.5px] mb-1">
                <span class="text-slate-500 w-20 shrink-0">${esc(p.label)}</span>
                <span class="text-slate-800 font-semibold">: ${esc(p.value)}</span>
              </div>`).join('')}
          </div>` : ''}
        ${b.footer ? `<div class="text-[12px] font-semibold text-slate-700 uppercase tracking-wider leading-relaxed whitespace-pre-line">${esc(b.footer)}</div>` : ''}
      </div>`,
  },
  
  /* ---------- HEADINGS berjenjang ---------- */
  section: {
    validate: (b) => typeof b.heading === 'string',
    weight: () => 40,
    render: (b) => `<h3 class="text-[16px] font-bold text-slate-900 mt-6 mb-3 flex items-baseline gap-2">
      ${b.num ? `<span class="text-brand-600">${esc(b.num)}.</span>` : ''}${esc(b.heading)}
    </h3>`,
  },
  
  heading: {
    validate: (b) => typeof b.text === 'string',
    weight: () => 30,
    render: (b) => `<h4 class="text-[14px] font-bold text-slate-900 mt-5 mb-2 flex items-baseline gap-2">
      ${b.num ? `<span class="text-slate-500">${esc(b.num)}.</span>` : ''}${esc(b.text)}
    </h4>`,
  },
  
  /* backward compat */
  subheading: {
    validate: (b) => typeof b.text === 'string',
    weight: () => 25,
    render: (b) => `<h4 class="text-[13px] font-semibold text-slate-900 mt-4 mb-1 flex items-center gap-2">
      <span class="w-1 h-3 bg-brand-500 rounded-full"></span>${esc(b.text)}</h4>`,
  },
  
  subsubsection: {
    validate: (b) => typeof b.text === 'string',
    weight: () => 25,
    render: (b) => `<h5 class="text-[13px] font-semibold text-slate-800 mt-4 mb-1.5">
      ${b.num ? `<span class="text-slate-500">${esc(b.num)}.</span> ` : ''}${esc(b.text)}
    </h5>`,
  },
  
  /* ---------- PARAGRAF / LIST / STEPS ---------- */
  paragraph: {
    validate: (b) => typeof b.text === 'string',
    weight: (b) => Math.max(20, Math.ceil((b.text?.length || 0) / 5)),
    render: (b) => `<p class="text-[14.5px] text-slate-700 leading-relaxed">${esc(b.text)}</p>`,
  },
  
  list: {
    validate: (b) => Array.isArray(b.items),
    weight: (b) => 15 + b.items.length * 22,
    render: (b) => `<ul class="space-y-1.5 mt-1">
      ${b.items.map(t=>`<li class="text-[14px] text-slate-700 flex gap-2.5 leading-relaxed">
        <span class="w-1.5 h-1.5 rounded-full bg-brand-400 mt-2 shrink-0"></span><span>${esc(t)}</span></li>`).join('')}
    </ul>`,
  },
  
  steps: {
    validate: (b) => Array.isArray(b.items),
    weight: (b) => 30 + b.items.length * 55,
    render: (b) => `<ol class="space-y-3 mt-1">
      ${b.items.map((s,i)=>`
        <li class="flex gap-3">
          <div class="w-6 h-6 rounded-full bg-brand-50 border border-brand-200 text-brand-700 text-[11px] font-bold grid place-items-center shrink-0 mt-0.5">${i+1}</div>
          <div>
            <div class="text-[13px] font-semibold text-slate-900">${esc(s.step)}</div>
            <div class="text-[13px] text-slate-600 leading-relaxed">${esc(s.text)}</div>
          </div>
        </li>`).join('')}
    </ol>`,
  },
  
  /* ---------- TABEL ---------- */
  table: {
    validate: (b) => Array.isArray(b.headers) && Array.isArray(b.rows),
    weight: (b) => 40 + b.rows.length * 40,
    render: (b) => `
      <div class="overflow-x-auto rounded-xl border border-slate-200 mt-2">
        <table class="w-full text-[13px]">
          <thead><tr>${b.headers.map(h=>`<th class="text-left font-semibold text-slate-700 px-3.5 py-2.5 border-b border-slate-200 whitespace-nowrap">${esc(h)}</th>`).join('')}</tr></thead>
          <tbody>${b.rows.map(r=>`<tr class="hover:bg-slate-50/70 transition">
            ${r.map((c,i)=>`<td class="px-3.5 py-2.5 text-slate-600 align-top ${i===0?'font-medium text-slate-800':''}">${esc(c)}</td>`).join('')}
          </tr>`).join('')}</tbody>
        </table>
      </div>`,
  },
  
  /* ---------- IDENTITY GRID ---------- */
  identity: {
    validate: (b) => Array.isArray(b.fields),
    weight: (b) => 40 + b.fields.length * 25,
    render: (b) => `
      <div class="mt-2 bg-slate-50/60 border border-slate-200 rounded-xl p-5">
        ${b.title ? `<div class="text-[11px] uppercase tracking-widest text-slate-500 font-bold mb-3">${esc(b.title)}</div>` : ''}
        <div class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2.5 text-[13px]">
          ${b.fields.map(f=>`
            <div class="flex gap-3 border-b border-slate-200/60 pb-1.5">
              <span class="text-slate-500 w-36 shrink-0">${esc(f.label)}</span>
              <span class="text-slate-800 font-medium">: ${esc(f.value || '—')}</span>
            </div>`).join('')}
        </div>
      </div>`,
  },
  
  /* ---------- PATHWAY ---------- */
  pathway: {
    validate: (b) => Array.isArray(b.steps),
    weight: (b) => 60 + b.steps.length * 45,
    render: (b) => `
      <div class="mt-3 bg-white border border-slate-200 rounded-xl p-6">
        ${b.title ? `<div class="text-[11px] uppercase tracking-widest text-slate-500 font-bold mb-4 text-center">${esc(b.title)}</div>` : ''}
        <div class="flex flex-col items-center gap-0">
          ${b.steps.map((s, i) => `
            <div class="w-full max-w-md">
              <div class="px-4 py-2.5 rounded-lg border-2 ${s.highlight ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-brand-200 bg-brand-50/50 text-brand-900'} text-[12.5px] font-medium text-center">
                ${esc(s.text)}
              </div>
              ${i < b.steps.length - 1 ? `<div class="text-center text-slate-300 my-1">↓</div>` : ''}
            </div>`).join('')}
        </div>
      </div>`,
  },
  
  /* ---------- BIBLIOGRAPHY ---------- */
  bibliography: {
    validate: (b) => Array.isArray(b.items),
    weight: (b) => 30 + b.items.length * 40,
    render: (b) => `
      <div class="mt-2 space-y-3">
        ${b.items.map((ref, i) => `
          <div class="flex gap-3 text-[13px] text-slate-700 leading-relaxed pl-6 -indent-6">
            <span class="font-semibold text-slate-500 shrink-0">${i+1}.</span>
            <span>${esc(ref)}</span>
          </div>`).join('')}
      </div>`,
  },
  
  /* ---------- ANALYSIS (Logbook) ---------- */
  analysis: {
    validate: (b) => b.title || b.items,
    weight: () => 80,
    render: (b) => `
      <div class="mt-3 border border-slate-200 rounded-xl overflow-hidden">
        <div class="px-4 py-2.5 bg-gradient-to-r from-brand-50 to-white border-b border-slate-200">
          <div class="text-[11px] uppercase tracking-widest text-brand-700 font-bold">${esc(b.title || 'Analisa')}</div>
        </div>
        <div class="divide-y divide-slate-100">
          ${(b.items || []).map(it => `
            <div class="p-4">
              <div class="text-[12.5px] font-bold text-slate-900 mb-1.5">${esc(it.label)}</div>
              <div class="text-[13px] text-slate-600 leading-relaxed mb-2">${esc(it.content)}</div>
              ${it.rationale ? `
                <div class="mt-2 pl-3 border-l-2 border-brand-400 bg-brand-50/40 py-2 pr-3 rounded-r">
                  <div class="text-[10px] uppercase tracking-widest text-brand-700 font-bold mb-0.5">Rasional</div>
                  <div class="text-[12.5px] text-brand-900 italic leading-relaxed">${esc(it.rationale)}</div>
                </div>` : ''}
            </div>`).join('')}
        </div>
      </div>`,
  },
  
  /* ---------- QUOTE / CALLOUT / DIAGNOSA / SOAP ---------- */
  quote: {
    validate: (b) => typeof b.text === 'string',
    weight: () => 60,
    render: (b) => `<blockquote class="mt-3 pl-4 border-l-2 border-brand-400 bg-brand-50/40 py-3 pr-3 rounded-r-lg">
      <p class="text-[13.5px] text-brand-900 italic font-serif leading-relaxed">"${esc(b.text)}"</p>
    </blockquote>`,
  },
  
  callout: {
    validate: (b) => typeof b.text === 'string',
    weight: () => 55,
    render: (b) => {
      const v = b.variant === 'warning' ?
        'bg-amber-50 border-amber-200 text-amber-900' :
        'bg-sky-50 border-sky-200 text-sky-900';
      return `<div class="mt-3 flex gap-3 p-3.5 rounded-xl border ${v}">
        <i data-lucide="${esc(b.icon||'info')}" class="w-4 h-4 shrink-0 mt-0.5"></i>
        <p class="text-[13px] leading-relaxed">${esc(b.text)}</p>
      </div>`;
    },
  },
  
  diagnosa: {
    validate: (b) => typeof b.title === 'string',
    weight: () => 90,
    render: (b) => `<div class="mt-2.5 p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-brand-200 transition">
      <span class="text-[10px] font-semibold uppercase tracking-wider text-brand-700 bg-brand-100 px-2 py-0.5 rounded">${esc(b.priority||'')}</span>
      <div class="text-[14px] font-semibold text-slate-900 mt-1.5">${esc(b.title)}</div>
      <p class="text-[13px] text-slate-600 leading-relaxed mt-1">${esc(b.detail||'')}</p>
    </div>`,
  },
  
  soap: {
    validate: (b) => b.s && b.o && b.a && b.p,
    weight: () => 130,
    render: (b) => `<div class="mt-2 grid grid-cols-2 gap-2.5">
      ${[['S','Data Subjektif',b.s,'sky'],['O','Data Objektif',b.o,'violet'],['A','Analisis',b.a,'amber'],['P','Perencanaan',b.p,'emerald']]
        .map(([k,label,val,c])=>`
        <div class="p-3 rounded-xl bg-${c}-50/60 border border-${c}-100">
          <div class="flex items-center gap-2 mb-1">
            <span class="w-5 h-5 rounded-md bg-${c}-500 text-white text-[10px] font-bold grid place-items-center">${k}</span>
            <span class="text-[11px] font-semibold text-${c}-900 uppercase tracking-wide">${label}</span>
          </div>
          <p class="text-[12.5px] text-slate-700 leading-relaxed">${esc(val)}</p>
        </div>`).join('')}
    </div>`,
  },
};
/* ============================================================
   DOCUMENTS — Data lengkap mengikuti template baku
   LP · ASKEP · Logbook · SOP
============================================================ */
export const DOCUMENTS = [
  /* ============================================================
     LP — LAPORAN PENDAHULUAN : HIPERTENSI
  ============================================================ */
  {
    id: 'lp-htn',
    type: 'lp',
    title: 'Laporan Pendahuluan: Asuhan Keperawatan pada Pasien Hipertensi',
    subtitle: 'Tinjauan Teori & Konsep Dasar Keperawatan Medikal Bedah',
    ruangan: 'Akademik',
    author: 'Ahmad Fauzi, S.Kep',
    clinicalTeacher: 'Ns. Rina W., M.Kep',
    clinicalInstructor: '—',
    date: '20 September 2025',
    tags: ['Hipertensi', 'Kardiovaskular', 'Tinjauan Teori'],
    stats: { words: 2400, readTime: 15 },
    summary: 'Laporan pendahuluan hipertensi mencakup tinjauan teori penyakit, konsep kebutuhan dasar manusia (mobilisasi & perfusi jaringan), dan konsep asuhan keperawatan berdasarkan SDKI, SLKI, dan SIKI.',
    sections: [
      /* ---------- COVER ---------- */
      {
        id: 'cover', heading: '', isCover: true,
        blocks: [{
          type: 'cover',
          header: 'Universitas Indonesia\nFakultas Ilmu Keperawatan',
          category: 'Laporan Pendahuluan',
          judul: 'Asuhan Keperawatan pada Pasien dengan Hipertensi',
          penyusun: [
            { label: 'Nama',     value: 'Ahmad Fauzi, S.Kep' },
            { label: 'NIM',      value: '202103045' },
            { label: 'Kelompok', value: 'A-2021' },
          ],
          footer: 'Program Studi Ilmu Keperawatan\n2025',
        }],
      },

      /* ---------- BAB I ---------- */
      {
        id: 'bab1', num: 'BAB I', heading: 'TINJAUAN TEORI KASUS',
        keywords: ['teori', 'konsep penyakit', 'pathway'],
        blocks: [
          { type: 'section', num: 'A', heading: 'Konsep Penyakit' },
          { type: 'heading', num: '1', text: 'Pengertian' },
          { type: 'paragraph', text: 'Hipertensi atau tekanan darah tinggi adalah kondisi kronis ketika tekanan darah pada dinding arteri meningkat secara persisten. Menurut PERHI (2021), seseorang didiagnosis hipertensi jika tekanan darah sistolik ≥140 mmHg dan/atau diastolik ≥90 mmHg pada dua kali pengukuran berbeda.' },

          { type: 'heading', num: '2', text: 'Penyebab / Etiologi' },
          { type: 'subsubsection', num: 'a', text: 'Hipertensi Primer (Esensial)' },
          { type: 'list', items: [
            'Faktor genetik / riwayat keluarga',
            'Obesitas dan resistensi insulin',
            'Konsumsi garam berlebih (>6 g/hari)',
            'Stres psikologis kronis',
            'Merokok & konsumsi alkohol',
          ]},
          { type: 'subsubsection', num: 'b', text: 'Hipertensi Sekunder' },
          { type: 'list', items: [
            'Penyakit ginjal (glomerulonefritis, pielonefritis)',
            'Kelainan endokrin (hipertiroidisme, feokromositoma)',
            'Koarktasio aorta',
            'Konsumsi obat-obatan (kortikosteroid, kontrasepsi oral)',
          ]},

          { type: 'heading', num: '3', text: 'Patofisiologi' },
          { type: 'paragraph', text: 'Peningkatan curah jantung dan/atau tahanan perifer menyebabkan peningkatan tekanan arteri. Aktivasi sistem renin-angiotensin-aldosteron (RAAS) memicu retensi natrium dan air, meningkatkan volume intravaskular. Remodeling vaskular berkelanjutan menyebabkan kekakuan dinding arteri dan memperberat hipertensi.' },

          { type: 'heading', num: '4', text: 'Tanda dan Gejala' },
          { type: 'table',
            headers: ['Gejala Umum', 'Gejala Berat (Krisis Hipertensi)'],
            rows: [
              ['Nyeri kepala oksipital', 'Nyeri kepala hebat'],
              ['Pusing & vertigo', 'Penglihatan kabur'],
              ['Epistaksis', 'Sesak napas'],
              ['Mudah lelah', 'Nyeri dada'],
              ['Tinnitus', 'Penurunan kesadaran'],
            ],
          },

          { type: 'heading', num: '5', text: 'Pemeriksaan Penunjang' },
          { type: 'table',
            headers: ['Pemeriksaan', 'Nilai Normal', 'Interpretasi Hipertensi'],
            rows: [
              ['TD (mmHg)', '<120/80', '≥140/90'],
              ['EKG', 'Irama sinus normal', 'LVH, iskemik'],
              ['Ureum/Kreatinin', 'Normal', '↑ jika nefropati'],
              ['Elektrolit', 'Normal', 'Hipokalemia (sekunder)'],
              ['Funduskopi', 'Normal', 'Retinopati grade I–IV'],
              ['Ekokardiografi', 'Normal', 'Penebalan ventrikel kiri'],
            ],
          },

          { type: 'heading', num: '6', text: 'Penatalaksanaan Medis' },
          { type: 'subsubsection', num: 'a', text: 'Farmakologi' },
          { type: 'list', items: [
            'ACE inhibitor (captopril, lisinopril)',
            'ARB (losartan, valsartan)',
            'CCB (amlodipine, nifedipine)',
            'Diuretik (HCT, furosemide)',
            'Beta-blocker (bisoprolol, atenolol)',
          ]},
          { type: 'subsubsection', num: 'b', text: 'Non-Farmakologi' },
          { type: 'list', items: [
            'Diet DASH (rendah garam, tinggi kalium)',
            'Aktivitas fisik 30 menit, 5×/minggu',
            'Berhenti merokok & alkohol',
            'Manajemen stres & tidur cukup',
            'Penurunan BB jika obesitas',
          ]},

          { type: 'section', num: 'B', heading: 'Pathway / Pohon Masalah' },
          { type: 'pathway',
            title: 'Pathway Hipertensi',
            steps: [
              { text: 'Faktor risiko (genetik, gaya hidup, obesitas)' },
              { text: 'Aktivasi RAAS & retensi Na⁺/H₂O' },
              { text: 'Peningkatan volume & tahanan perifer' },
              { text: 'Hipertensi persisten (≥140/90 mmHg)' },
              { text: 'Komplikasi: Nyeri kepala, Perfusi serebral ↓, Risiko cedera', highlight: true },
            ],
          },
        ],
      },

      /* ---------- BAB II ---------- */
      {
        id: 'bab2', num: 'BAB II', heading: 'KONSEP KEBUTUHAN DASAR MANUSIA',
        keywords: ['KDM', 'perfusi', 'mobilisasi'],
        blocks: [
          { type: 'section', num: 'A', heading: 'Pengertian' },
          { type: 'paragraph', text: 'Kebutuhan dasar manusia adalah kebutuhan esensial yang harus dipenuhi untuk mempertahankan homeostasis dan kesejahteraan. Pada pasien hipertensi, kebutuhan yang terganggu utama adalah perfusi jaringan dan rasa nyaman (nyeri).' },

          { type: 'section', num: 'B', heading: 'Tujuan' },
          { type: 'list', items: [
            'Mempertahankan perfusi organ vital dalam batas adekuat.',
            'Mengurangi nyeri dan meningkatkan rasa nyaman.',
            'Mencegah komplikasi kardiovaskular dan serebrovaskular.',
            'Meningkatkan kemandirian pasien dalam manajemen hipertensi.',
          ]},

          { type: 'section', num: 'C', heading: 'Indikasi dan Kontraindikasi' },
          { type: 'table',
            headers: ['Aspek', 'Indikasi', 'Kontraindikasi'],
            rows: [
              ['Manajemen Nyeri', 'Nyeri skala ≥3', 'Nyeri akut abdomen belum terdiagnosis'],
              ['Mobilisasi', 'Hemodinamik stabil', 'TD >180/110 mmHg belum terkontrol'],
              ['Diet DASH', 'Hipertensi primer & sekunder', 'Gagal ginjal berat (batasi K⁺)'],
              ['Latihan Fisik', 'Hipertensi stage 1–2', 'Krisis hipertensi, angina aktif'],
            ],
          },
        ],
      },

      /* ---------- BAB III ---------- */
      {
        id: 'bab3', num: 'BAB III', heading: 'KONSEP ASUHAN KEPERAWATAN',
        keywords: ['askep', 'SDKI', 'SLKI', 'SIKI'],
        blocks: [
          { type: 'heading', num: '1', text: 'Pengkajian [Teori]' },
          { type: 'paragraph', text: 'Pengkajian keperawatan pada pasien hipertensi meliputi riwayat kesehatan (keluhan utama, riwayat penyakit sekarang/dahulu/keluarga), pola fungsi kesehatan Gordon (11 pola), pemeriksaan fisik fokus kardiovaskular, serta pemeriksaan penunjang.' },
          { type: 'table',
            headers: ['Pola Gordon', 'Fokus Kajian pada Hipertensi'],
            rows: [
              ['Persepsi-Kesehatan', 'Pengetahuan tentang hipertensi, kepatuhan obat'],
              ['Nutrisi-Metabolik', 'Pola makan, konsumsi garam, BB/TB'],
              ['Aktivitas-Latihan', 'Toleransi aktivitas, kelelahan, dispnea'],
              ['Tidur-Istirahat', 'Kualitas tidur, insomnia'],
              ['Kognitif-Perseptif', 'Nyeri kepala, pusing, penglihatan'],
              ['Persepsi diri', 'Kecemasan, stres psikologis'],
            ],
          },

          { type: 'heading', num: '2', text: 'Diagnosis Keperawatan [Teori]' },
          { type: 'list', items: [
            'Nyeri Akut (D.0077) — berhubungan dengan agen pencedera fisiologis.',
            'Risiko Perfusi Serebral Tidak Efektif (D.0017) — dibuktikan dengan hipertensi.',
            'Intoleransi Aktivitas (D.0056) — berhubungan dengan kelemahan.',
            'Ansietas (D.0080) — berhubungan dengan krisis situasional.',
          ]},

          { type: 'heading', num: '3', text: 'Intervensi Keperawatan [Teori]' },
          { type: 'table',
            headers: ['SDKI', 'SLKI', 'SIKI'],
            rows: [
              ['Nyeri Akut', 'Tingkat Nyeri (L.08066)', 'Manajemen Nyeri (I.08238)'],
              ['Risiko Perfusi Serebral', 'Perfusi Serebral (L.02014)', 'Manajemen Hipertensi (I.03114)'],
              ['Intoleransi Aktivitas', 'Toleransi Aktivitas (L.05047)', 'Manajemen Energi (I.05178)'],
              ['Ansietas', 'Tingkat Ansietas (L.09093)', 'Reduksi Ansietas (I.09326)'],
            ],
          },

          { type: 'heading', num: '4', text: 'Implementasi Keperawatan [Teori]' },
          { type: 'paragraph', text: 'Implementasi keperawatan dilakukan berdasarkan SIKI, mencakup tindakan observasi (monitoring TD, skala nyeri), terapeutik (manajemen nyeri non-farmakologis), edukasi (diet DASH, kepatuhan obat), dan kolaborasi (pemberian antihipertensi).' },

          { type: 'heading', num: '5', text: 'Evaluasi Keperawatan [Teori]' },
          { type: 'paragraph', text: 'Evaluasi menggunakan format SOAP (Subjektif, Objektif, Analisis, Planning). Kriteria hasil mengacu pada SLKI: skala nyeri menurun, TD dalam rentang normal, pasien mampu mempertahankan aktivitas tanpa kelelahan.' },
        ],
      },

      /* ---------- DAFTAR PUSTAKA ---------- */
      {
        id: 'daftar-pustaka', num: '', heading: 'DAFTAR PUSTAKA',
        keywords: ['referensi', 'APA'],
        blocks: [
          { type: 'bibliography',
            items: [
              'Brunner, L. S., & Suddarth, D. S. (2020). Brunner & Suddarth\'s textbook of medical-surgical nursing (14th ed.). Wolters Kluwer.',
              'Kementerian Kesehatan RI. (2021). Pedoman pengendalian hipertensi. Kemenkes RI.',
              'Perhimpunan Dokter Hipertensi Indonesia. (2021). Konsensus penatalaksanaan hipertensi 2021. PERHI.',
              'Tim Pokja SDKI DPP PPNI. (2017). Standar diagnosis keperawatan Indonesia (Edisi 1). DPP PPNI.',
              'Tim Pokja SLKI DPP PPNI. (2019). Standar luaran keperawatan Indonesia (Edisi 1). DPP PPNI.',
              'Tim Pokja SIKI DPP PPNI. (2018). Standar intervensi keperawatan Indonesia (Edisi 1). DPP PPNI.',
            ],
          },
        ],
      },
    ],
  },

  /* ============================================================
     ASKEP — ASUHAN KEPERAWATAN : HIPERTENSI (Tn. S)
  ============================================================ */
  {
    id: 'askep-htn',
    type: 'askep',
    title: 'Asuhan Keperawatan pada Tn. S dengan Hipertensi',
    subtitle: 'RSUD Dr. Soetomo · Periode 10–12 Oktober 2025',
    ruangan: 'Irina C2',
    author: 'Ahmad Fauzi, S.Kep',
    clinicalTeacher: 'Ns. Rina W., M.Kep (Dosen)',
    clinicalInstructor: 'Ns. Dita P., S.Kep (CI Ruang)',
    date: '12 Oktober 2025',
    tags: ['Hipertensi Stage 2', 'Dewasa', 'Rawat Inap'],
    stats: { words: 1900, readTime: 12 },
    summary: 'Asuhan keperawatan komprehensif pada Tn. S dengan hipertensi stage 2 disertai nyeri kepala. Fokus intervensi pada manajemen nyeri, stabilisasi TD, dan edukasi diet DASH.',
    sections: [
      /* ---------- COVER ---------- */
      {
        id: 'cover', heading: '', isCover: true,
        blocks: [{
          type: 'cover',
          header: 'Universitas Indonesia\nFakultas Ilmu Keperawatan',
          category: 'Asuhan Keperawatan',
          judul: 'Asuhan Keperawatan pada Tn. S dengan Hipertensi',
          penyusun: [
            { label: 'Nama',   value: 'Ahmad Fauzi, S.Kep' },
            { label: 'NIM',    value: '202103045' },
            { label: 'Ruang',  value: 'Irina C2' },
          ],
          footer: 'Program Profesi Ners\n2025',
        }],
      },

      /* ---------- 1. IDENTITAS ---------- */
      {
        id: 'id-pasien', num: '1', heading: 'Identitas Pasien',
        keywords: ['identitas', 'biodata'],
        blocks: [
          { type: 'identity',
            title: 'Data Pasien',
            fields: [
              { label: 'Nama',              value: 'Tn. S' },
              { label: 'Umur',              value: '55 tahun' },
              { label: 'Jenis Kelamin',     value: 'Laki-laki' },
              { label: 'Status Perkawinan', value: 'Kawin' },
              { label: 'Pekerjaan',         value: 'Wiraswasta' },
              { label: 'Pendidikan',        value: 'SMA' },
              { label: 'Agama',             value: 'Islam' },
              { label: 'Alamat',            value: 'Jl. Kenanga No. 45, Surabaya' },
              { label: 'No. RM',            value: '1120998' },
              { label: 'Tanggal MRS',       value: '10 Oktober 2025' },
              { label: 'Diagnosa Medis',    value: 'Hipertensi Stage 2' },
              { label: 'Ruang/Kelas',       value: 'Irina C2 / Kelas III' },
            ],
          },
        ],
      },

      /* ---------- 2. PENGKAJIAN ---------- */
      {
        id: 'pengkajian', num: '2', heading: 'Pengkajian Keperawatan',
        keywords: ['pengkajian', 'Gordon', 'anamnesis'],
        blocks: [
          { type: 'section', num: 'A', heading: 'Riwayat Kesehatan' },
          { type: 'subsubsection', num: 'a', text: 'Riwayat Kesehatan Sekarang' },
          { type: 'paragraph', text: 'Pasien datang ke IGD RSUD pada 10 Oktober 2025 pukul 08.30 WIB dengan keluhan nyeri kepala berdenyut sejak 3 hari SMRS. Nyeri dirasakan terutama di bagian oksipital, skala 6/10, memberat saat beraktivitas. Pasien juga mengeluh pusing dan mudah lelah.' },
          { type: 'subsubsection', num: 'b', text: 'Riwayat Kesehatan Dahulu' },
          { type: 'paragraph', text: 'Pasien memiliki riwayat hipertensi sejak 5 tahun lalu namun tidak rutin mengonsumsi obat antihipertensi. Tidak ada riwayat DM, jantung, atau stroke.' },
          { type: 'subsubsection', num: 'c', text: 'Riwayat Kesehatan Keluarga' },
          { type: 'paragraph', text: 'Ayah pasien memiliki riwayat hipertensi. Tidak ada riwayat penyakit menular dalam keluarga.' },

          { type: 'section', num: 'B', heading: 'Pola Fungsi Kesehatan Gordon' },
          { type: 'table',
            headers: ['Pola', 'Data Hasil Pengkajian'],
            rows: [
              ['Persepsi Kesehatan', 'Pasien menganggap hipertensi bukan penyakit serius, tidak rutin kontrol.'],
              ['Nutrisi-Metabolik', 'Makan 3×/hari, sering mengonsumsi makanan asin & gorengan. BB 82 kg, TB 168 cm (IMT 29,1 — obesitas).'],
              ['Aktivitas-Latihan', 'Aktivitas ringan, tidak rutin olahraga. Dispnea saat aktivitas berat.'],
              ['Tidur-Istirahat', 'Tidur 6 jam/hari, sering terbangun karena nyeri kepala.'],
              ['Kognitif-Perseptif', 'Nyeri kepala skala 6/10, pusing, penglihatan kabur sesaat.'],
              ['Persepsi Diri', 'Cemas dengan kondisinya, khawatir biaya pengobatan.'],
              ['Peran-Hubungan', 'Suami dari Ny. R, hubungan sosial baik dengan tetangga.'],
              ['Seksualitas-Reproduksi', 'Tidak ada keluhan.'],
              ['Koping-Toleransi Stres', 'Koping adaptif, dukungan keluarga baik.'],
              ['Nilai-Kepercayaan', 'Islam, sholat 5 waktu saat sehat.'],
            ],
          },

          { type: 'section', num: 'C', heading: 'Pengkajian Fisik (Data Fokus)' },
          { type: 'table',
            headers: ['Parameter', 'Hasil', 'Normal', 'Interpretasi'],
            rows: [
              ['Kesadaran', 'Compos mentis, GCS 15', 'GCS 15', 'Normal'],
              ['Tekanan Darah', '180/100 mmHg', '<120/80', '↑ Tinggi'],
              ['Nadi', '98 x/menit', '60–100', 'Normal'],
              ['RR', '22 x/menit', '16–20', '↑ Takipnea'],
              ['Suhu', '36.8 °C', '36.5–37.5', 'Normal'],
              ['SpO₂', '97%', '≥95%', 'Normal'],
              ['Skala Nyeri', '6/10 (oksipital)', '0/10', 'Sedang'],
            ],
          },

          { type: 'section', num: 'D', heading: 'Pemeriksaan Laboratorium' },
          { type: 'table',
            headers: ['Pemeriksaan', 'Hasil', 'Nilai Rujukan', 'Keterangan'],
            rows: [
              ['Hemoglobin', '13.2 g/dL', '13–17', 'Normal'],
              ['Leukosit', '8.500/µL', '4.000–10.000', 'Normal'],
              ['Trombosit', '255.000/µL', '150.000–400.000', 'Normal'],
              ['Ureum', '32 mg/dL', '15–45', 'Normal'],
              ['Kreatinin', '1.1 mg/dL', '0.7–1.3', 'Normal'],
              ['Natrium', '142 mEq/L', '135–145', 'Normal'],
              ['Kalium', '4.2 mEq/L', '3.5–5.0', 'Normal'],
              ['Kolesterol Total', '245 mg/dL', '<200', '↑ Tinggi'],
            ],
          },

          { type: 'section', num: 'E', heading: 'Terapi Obat' },
          { type: 'table',
            headers: ['Nama Obat', 'Dosis', 'Rute', 'Frekuensi', 'Indikasi'],
            rows: [
              ['Amlodipine', '10 mg', 'Oral', '1×/hari (pagi)', 'Antihipertensi (CCB)'],
              ['Captopril', '25 mg', 'Oral', '3×/hari', 'Antihipertensi (ACE-I)'],
              ['Ketorolac', '30 mg', 'IV', '3×/hari', 'Analgesik nyeri kepala'],
              ['Ranitidin', '150 mg', 'Oral', '2×/hari', 'Protektor lambung'],
              ['Simvastatin', '20 mg', 'Oral', '1×/hari (malam)', 'Penurun kolesterol'],
            ],
          },
        ],
      },

      /* ---------- 3. ANALISIS DATA ---------- */
      {
        id: 'analisis', num: '3', heading: 'Analisis Data',
        keywords: ['analisis', 'PES', 'data'],
        blocks: [
          { type: 'paragraph', text: 'Analisis data menggunakan format PES (Problem, Etiologi, Sign/Symptom) berdasarkan data subjektif (D.s) dan data objektif (D.o).' },
          { type: 'table',
            headers: ['No', 'D.s (Data Subjektif)', 'D.o (Data Objektif)', 'Problem', 'Etiologi'],
            rows: [
              ['1', 'Pasien mengeluh nyeri kepala berdenyut, skala 6/10', 'Pasien tampak meringis, TD 180/100 mmHg', 'Nyeri Akut', 'Agen pencedera fisiologis (↑TD)'],
              ['2', 'Pasien mengeluh pusing saat beraktivitas', 'TD 180/100 mmHg, kolesterol 245 mg/dL', 'Risiko Perfusi Serebral Tidak Efektif', 'Hipertensi & hiperkolesterolemia'],
              ['3', 'Keluarga menyatakan tidak tahu cara merawat pasien hipertensi', 'Pasien tidak rutin kontrol, diet tidak terkontrol', 'Manajemen Kesehatan Keluarga Tidak Efektif', 'Kurang pengetahuan & dukungan'],
            ],
          },
        ],
      },

      /* ---------- 4. DIAGNOSA ---------- */
      {
        id: 'diagnosa', num: '4', heading: 'Diagnosa Keperawatan',
        keywords: ['diagnosa', 'SDKI'],
        blocks: [
          { type: 'paragraph', text: 'Diagnosa keperawatan disusun berdasarkan SDKI dengan prioritas berdasarkan tingkat keparahan dan risiko.' },
          { type: 'table',
            headers: ['No. Dx', 'Diagnosa (SDKI)', 'D.s (Data Subjektif)', 'D.o (Data Objektif)', 'Prioritas'],
            rows: [
              ['I', 'Nyeri Akut (D.0077)', 'Nyeri kepala berdenyut skala 6/10', 'Tampak meringis, TD 180/100 mmHg', 'Utama'],
              ['II', 'Risiko Perfusi Serebral Tidak Efektif (D.0017)', 'Pusing saat aktivitas', 'Hipertensi stage 2, kolesterol tinggi', 'Kedua'],
              ['III', 'Manajemen Kesehatan Keluarga Tidak Efektif (D.0116)', 'Keluarga tidak tahu cara merawat', 'Pasien tidak rutin kontrol, diet tidak terkontrol', 'Ketiga'],
            ],
          },
        ],
      },

      /* ---------- 5. INTERVENSI ---------- */
      {
        id: 'intervensi', num: '5', heading: 'Intervensi Keperawatan',
        keywords: ['intervensi', 'SLKI', 'SIKI', 'rasional'],
        blocks: [
          { type: 'paragraph', text: 'Intervensi disusun berdasarkan SLKI (luaran) dan SIKI (intervensi) dengan menyertakan rasional ilmiah.' },
          { type: 'table',
            headers: ['No. Dx', 'SLKI (Luaran)', 'SIKI (Intervensi)', 'Rasional'],
            rows: [
              [
                'I',
                'Tingkat Nyeri (L.08066): skala nyeri menurun (≤3), ekspresi wajah rileks',
                'Manajemen Nyeri (I.08238): kaji nyeri (PQRST), atur posisi semi-Fowler, ajarkan relaksasi nafas dalam, kolaborasi analgesik',
                'Posisi semi-Fowler menurunkan tekanan intrakranial; relaksasi mengurangi ketegangan otot; analgesik memblokir jalur nyeri',
              ],
              [
                'II',
                'Perfusi Serebral (L.02014): TD dalam rentang normal, tidak ada pusing',
                'Manajemen Hipertensi (I.03114): monitor TD tiap 4 jam, kolaborasi antihipertensi (amlodipine, captopril), batasi aktivitas berat',
                'Monitoring mendeteksi perubahan dini; antihipertensi menurunkan afterload; pembatasan aktivitas mencegah lonjakan TD',
              ],
              [
                'III',
                'Manajemen Kesehatan (L.12107): keluarga mampu mengenali tanda bahaya & mendukung diet',
                'Edukasi Proses Penyakit (I.12399): jelaskan diet DASH, ajarkan cara minum obat, jadwalkan kontrol rutin',
                'Pengetahuan keluarga meningkatkan kepatuhan; diet DASH menurunkan TD 5–10 mmHg; kontrol rutin mencegah komplikasi',
              ],
            ],
          },
        ],
      },

      /* ---------- 6. IMPLEMENTASI ---------- */
      {
        id: 'implementasi', num: '6', heading: 'Implementasi Keperawatan',
        keywords: ['implementasi', 'SIKI', 'shift'],
        blocks: [
          { type: 'paragraph', text: 'Implementasi dilaksanakan selama 3 hari (10–12 Oktober 2025) mencakup 3 shift per hari: pagi (07.00–14.00), sore (14.00–21.00), malam (21.00–07.00).' },

          { type: 'subsubsection', num: 'a', text: 'Hari 1 — 10 Oktober 2025' },
          { type: 'table',
            headers: ['No. SIKI', 'Jam', 'Implementasi', 'Kategori'],
            rows: [
              ['I.08238', '08.45', 'Mengkaji nyeri (lokasi, skala, karakteristik)', 'Observasi'],
              ['I.08238', '08.50', 'Mengatur posisi semi-Fowler 30°', 'Terapeutik'],
              ['I.08238', '09.00', 'Mengajarkan teknik relaksasi nafas dalam', 'Edukasi'],
              ['I.08238', '09.15', 'Kolaborasi pemberian Ketorolac 30 mg IV', 'Kolaborasi'],
              ['I.03114', '09.30', 'Monitor TD tiap 4 jam', 'Observasi'],
              ['I.03114', '10.00', 'Kolaborasi pemberian Amlodipine 10 mg & Captopril 25 mg', 'Kolaborasi'],
              ['I.12399', '14.30', 'Edukasi diet DASH — batasi garam ≤5 g/hari', 'Edukasi'],
              ['I.12399', '15.00', 'Mengajarkan cara minum obat yang benar & jadwal kontrol', 'Edukasi'],
            ],
          },

          { type: 'subsubsection', num: 'b', text: 'Hari 2 — 11 Oktober 2025' },
          { type: 'table',
            headers: ['No. SIKI', 'Jam', 'Implementasi', 'Kategori'],
            rows: [
              ['I.08238', '07.30', 'Mengkaji ulang skala nyeri (hasil: 4/10)', 'Observasi'],
              ['I.08238', '07.45', 'Mempertahankan posisi semi-Fowler', 'Terapeutik'],
              ['I.03114', '08.00', 'Monitor TD (hasil: 165/95 mmHg)', 'Observasi'],
              ['I.03114', '08.30', 'Kolaborasi antihipertensi pagi', 'Kolaborasi'],
              ['I.12399', '10.00', 'Mendiskusikan menu DASH dengan keluarga', 'Edukasi'],
              ['I.12399', '15.00', 'Mengajarkan manajemen stres (distraksi, relaksasi)', 'Edukasi'],
            ],
          },

          { type: 'subsubsection', num: 'c', text: 'Hari 3 — 12 Oktober 2025' },
          { type: 'table',
            headers: ['No. SIKI', 'Jam', 'Implementasi', 'Kategori'],
            rows: [
              ['I.08238', '07.30', 'Mengkaji nyeri (hasil: 2/10)', 'Observasi'],
              ['I.03114', '08.00', 'Monitor TD (hasil: 140/85 mmHg)', 'Observasi'],
              ['I.12399', '09.00', 'Evaluasi pemahaman pasien & keluarga tentang diet & obat', 'Edukasi'],
              ['I.12399', '10.00', 'Menyusun discharge planning bersama pasien', 'Edukasi'],
            ],
          },
        ],
      },

      /* ---------- 7. EVALUASI ---------- */
      {
        id: 'evaluasi', num: '7', heading: 'Evaluasi Keperawatan',
        keywords: ['evaluasi', 'SOAP'],
        blocks: [
          { type: 'paragraph', text: 'Evaluasi disusun menggunakan format SOAP (Subjektif, Objektif, Analisis, Planning) per diagnosa keperawatan.' },
          { type: 'table',
            headers: ['No. Dx', 'S (Subjektif)', 'O (Objektif)', 'A (Analisis)', 'P (Planning)'],
            rows: [
              [
                'I',
                'Pasien menyatakan nyeri kepala sudah berkurang, skala nyeri 2/10',
                'Pasien tampak rileks, TD 140/85 mmHg',
                'Masalah nyeri akut teratasi sebagian',
                'Lanjutkan manajemen nyeri non-farmakologis, hentikan analgesik IV, ganti oral bila perlu',
              ],
              [
                'II',
                'Pasien menyatakan tidak lagi pusing',
                'TD 140/85 mmHg, tidak ada tanda ↑ICP',
                'Risiko perfusi serebral menurun',
                'Pertahankan monitor TD, lanjutkan antihipertensi oral',
              ],
              [
                'III',
                'Keluarga menyatakan sudah memahami diet DASH & jadwal kontrol',
                'Keluarga mampu menyebutkan kembali 3 makanan yang harus dihindari',
                'Manajemen kesehatan keluarga meningkat',
                'Lanjutkan edukasi kontrol rutin, berikan leaflet discharge',
              ],
            ],
          },
        ],
      },
    ],
  },

  /* ============================================================
     LOGBOOK — PRAKTIK KLINIK
  ============================================================ */
  {
    id: 'logbook-htn',
    type: 'logbook',
    title: 'Logbook Praktik Klinik — Kasus Hipertensi',
    subtitle: 'Program Profesi Ners · Semester Ganjil 2025/2026',
    ruangan: 'Irina C2',
    author: 'Ahmad Fauzi (NIM: 202103045)',
    clinicalTeacher: 'Ns. Rina W., M.Kep',
    clinicalInstructor: 'Ns. Dita P., S.Kep',
    date: '10–12 Oktober 2025',
    tags: ['Logbook', 'Hipertensi', 'Praktik Klinik'],
    stats: { words: 1100, readTime: 7 },
    summary: 'Analisis tindakan keperawatan pada pasien Tn. S dengan hipertensi, mencakup pengkajian, diagnosa, intervensi, implementasi, dan evaluasi berdasarkan SDKI, SLKI, dan SIKI beserta rasional ilmiah.',
    sections: [
      /* ---------- COVER ---------- */
      {
        id: 'cover', heading: '', isCover: true,
        blocks: [{
          type: 'cover',
          header: 'Universitas Indonesia\nProgram Profesi Ners',
          category: 'Logbook Praktik Klinik',
          judul: 'Analisis Tindakan Keperawatan pada Tn. S dengan Hipertensi',
          penyusun: [
            { label: 'Nama',   value: 'Ahmad Fauzi' },
            { label: 'NIM',    value: '202103045' },
            { label: 'Ruang',  value: 'Irina C2' },
          ],
          footer: 'RSUD Dr. Soetomo\n2025',
        }],
      },

      /* ---------- 1. IDENTITAS ---------- */
      {
        id: 'id', num: '1', heading: 'Identitas Pasien',
        keywords: ['identitas'],
        blocks: [
          { type: 'identity',
            title: 'Data Pasien',
            fields: [
              { label: 'Nama',       value: 'Tn. S' },
              { label: 'Umur',       value: '55 tahun' },
              { label: 'Jenis Kelamin', value: 'Laki-laki' },
              { label: 'No. RM',     value: '1120998' },
              { label: 'Diagnosa Medis', value: 'Hipertensi Stage 2' },
              { label: 'Ruang',      value: 'Irina C2' },
              { label: 'Tanggal MRS', value: '10 Oktober 2025' },
              { label: 'Tanggal Kajian', value: '10–12 Oktober 2025' },
            ],
          },
        ],
      },

      /* ---------- 2. DIAGNOSA ---------- */
      {
        id: 'dx', num: '2', heading: 'Diagnosa Keperawatan',
        keywords: ['diagnosa', 'SDKI'],
        blocks: [
          { type: 'table',
            headers: ['No. Dx', 'Diagnosa Keperawatan (SDKI)'],
            rows: [
              ['I', 'Nyeri Akut (D.0077)'],
              ['II', 'Risiko Perfusi Serebral Tidak Efektif (D.0017)'],
              ['III', 'Manajemen Kesehatan Keluarga Tidak Efektif (D.0116)'],
            ],
          },
        ],
      },

      /* ---------- 3. TINDAKAN ---------- */
      {
        id: 'tindakan', num: '3', heading: 'Tindakan Keperawatan',
        keywords: ['tindakan'],
        blocks: [
          { type: 'table',
            headers: ['No. SIKI', 'Tanggal', 'Jam', 'Tindakan', 'Kategori'],
            rows: [
              ['I.08238', '10 Okt 2025', '08.45', 'Kaji nyeri (PQRST)', 'Observasi'],
              ['I.08238', '10 Okt 2025', '08.50', 'Atur posisi semi-Fowler 30°', 'Terapeutik'],
              ['I.08238', '10 Okt 2025', '09.00', 'Ajarkan relaksasi nafas dalam', 'Edukasi'],
              ['I.08238', '10 Okt 2025', '09.15', 'Kolaborasi Ketorolac 30 mg IV', 'Kolaborasi'],
              ['I.03114', '10 Okt 2025', '09.30', 'Monitor TD', 'Observasi'],
              ['I.03114', '10 Okt 2025', '10.00', 'Kolaborasi Amlodipine & Captopril', 'Kolaborasi'],
              ['I.12399', '10 Okt 2025', '14.30', 'Edukasi diet DASH', 'Edukasi'],
              ['I.08238', '11 Okt 2025', '07.30', 'Re-kaji nyeri (4/10)', 'Observasi'],
              ['I.03114', '11 Okt 2025', '08.00', 'Monitor TD (165/95)', 'Observasi'],
              ['I.12399', '11 Okt 2025', '10.00', 'Diskusi menu DASH dengan keluarga', 'Edukasi'],
              ['I.08238', '12 Okt 2025', '07.30', 'Re-kaji nyeri (2/10)', 'Observasi'],
              ['I.03114', '12 Okt 2025', '08.00', 'Monitor TD (140/85)', 'Observasi'],
              ['I.12399', '12 Okt 2025', '10.00', 'Discharge planning bersama pasien', 'Edukasi'],
            ],
          },
        ],
      },

      /* ---------- 4. ANALISA TINDAKAN ---------- */
      {
        id: 'analisa', num: '4', heading: 'Analisa Tindakan Keperawatan',
        keywords: ['analisa', 'rasional'],
        blocks: [
          { type: 'paragraph', text: 'Analisa tindakan keperawatan mencakup rasional ilmiah untuk setiap tahapan proses keperawatan (pengkajian, diagnosa, intervensi, implementasi, evaluasi).' },

          { type: 'analysis',
            title: 'A. Analisa Pengkajian',
            items: [
              {
                label: 'D.s (Data Subjektif)',
                content: 'Pasien mengeluh nyeri kepala berdenyut skala 6/10, pusing saat beraktivitas.',
                rationale: 'Nyeri kepala oksipital adalah manifestasi klasik hipertensi akibat peningkatan tekanan intrakranial dan vasokonstriksi serebral (Brunner & Suddarth, 2020).',
              },
              {
                label: 'D.o (Data Objektif)',
                content: 'TD 180/100 mmHg, nadi 98 x/menit, RR 22 x/menit, pasien tampak meringis.',
                rationale: 'TD ≥140/90 mmHg mengonfirmasi hipertensi stage 2 (PERHI, 2021); takipnea mencerminkan respons kompensasi simpatis terhadap nyeri.',
              },
            ],
          },

          { type: 'analysis',
            title: 'B. Analisa Diagnosa Keperawatan',
            items: [
              {
                label: 'Diagnosa Utama: Nyeri Akut (D.0077)',
                content: 'Berhubungan dengan agen pencedera fisiologis (peningkatan tekanan darah).',
                rationale: 'SDKI menetapkan bahwa nyeri akut dengan durasi <3 bulan dan onset mendadak sesuai kriteria D.0077; etiologi "agen pencedera fisiologis" tepat untuk hipertensi (Tim Pokja SDKI, 2017).',
              },
              {
                label: 'Diagnosa Kedua: Risiko Perfusi Serebral Tidak Efektif (D.0017)',
                content: 'Dibuktikan dengan hipertensi dan hiperkolesterolemia.',
                rationale: 'Hipertensi persisten menyebabkan remodeling vaskular dan penurunan autoregulasi serebral, meningkatkan risiko iskemik (Brunner & Suddarth, 2020).',
              },
            ],
          },

          { type: 'analysis',
            title: 'C. Analisa Intervensi (SLKI)',
            items: [
              {
                label: 'Tingkat Nyeri (L.08066)',
                content: 'Target: skala nyeri menurun dari 6 menjadi ≤3 dalam 3×24 jam.',
                rationale: 'SLKI menetapkan luaran nyeri dengan indikator skala, ekspresi wajah, dan pola tidur; target realistis sesuai respons pasien terhadap analgesik & non-farmakologis.',
              },
              {
                label: 'Perfusi Serebral (L.02014)',
                content: 'Target: TD dalam rentang normal, tidak ada pusing.',
                rationale: 'Normalisasi TD menurunkan risiko iskemik serebral dan mempertahankan autoregulasi aliran darah otak.',
              },
            ],
          },

          { type: 'analysis',
            title: 'D. Analisa Implementasi (SIKI)',
            items: [
              {
                label: 'Manajemen Nyeri (I.08238)',
                content: 'Kaji nyeri (PQRST), atur posisi semi-Fowler, ajarkan relaksasi nafas dalam, kolaborasi analgesik.',
                rationale: 'Posisi semi-Fowler menurunkan tekanan intrakranial; relaksasi nafas dalam merangsang sistem parasimpatis untuk mengurangi persepsi nyeri; Ketorolac menghambat sintesis prostaglandin.',
              },
              {
                label: 'Manajemen Hipertensi (I.03114)',
                content: 'Monitor TD tiap 4 jam, kolaborasi Amlodipine 10 mg & Captopril 25 mg.',
                rationale: 'Amlodipine (CCB) menghambat influx kalsium di otot polos vaskular; Captopril (ACE-I) menghambat konversi angiotensin I → II, menurunkan tahanan perifer.',
              },
              {
                label: 'Edukasi Proses Penyakit (I.12399)',
                content: 'Ajarkan diet DASH, cara minum obat, jadwal kontrol.',
                rationale: 'Pengetahuan pasien & keluarga meningkatkan kepatuhan; diet DASH terbukti menurunkan TD sistolik 5–10 mmHg (Kemenkes RI, 2021).',
              },
            ],
          },

          { type: 'analysis',
            title: 'E. Analisa Evaluasi (SOAP)',
            items: [
              {
                label: 'S — Subjektif',
                content: 'Pasien menyatakan nyeri kepala berkurang (2/10), tidak lagi pusing.',
                rationale: 'Perbaikan subjektif mencerminkan efektivitas manajemen nyeri dan stabilisasi TD.',
              },
              {
                label: 'O — Objektif',
                content: 'TD 140/85 mmHg, pasien tampak rileks.',
                rationale: 'TD turun dari 180/100 → 140/85 menunjukkan respons positif terhadap antihipertensi.',
              },
              {
                label: 'A — Analisis',
                content: 'Masalah nyeri akut teratasi sebagian; risiko perfusi serebral menurun.',
                rationale: 'Kriteria hasil SLKI tercapai sebagian; intervensi dilanjutkan untuk mencapai target penuh.',
              },
              {
                label: 'P — Planning',
                content: 'Lanjutkan monitor TD, edukasi kontrol rutin, discharge planning.',
                rationale: 'Kontinuitas asuhan mencegah readmisi dan komplikasi jangka panjang (Brunner & Suddarth, 2020).',
              },
            ],
          },
        ],
      },
    ],
  },

  /* ============================================================
     SOP — PEMASANGAN INFUS
  ============================================================ */
  {
    id: 'sop-infus',
    type: 'sop',
    title: 'SOP Pemasangan Infus (Intravena Kateter)',
    subtitle: 'Standar Prosedur Operasional Keperawatan · Revisi 03',
    ruangan: 'Seluruh Unit',
    author: 'Tim Keperawatan RSUD',
    clinicalTeacher: '—',
    clinicalInstructor: 'Komite Keperawatan',
    date: '1 Agustus 2025',
    tags: ['SOP', 'Prosedur Invasif', 'Aspek Legal'],
    stats: { words: 900, readTime: 6 },
    summary: 'Prosedur standar pemasangan infus untuk mencegah komplikasi vaskular dan infeksi, mencakup persiapan alat, langkah kerja, hingga dokumentasi keperawatan.',
    sections: [
      /* ---------- COVER ---------- */
      {
        id: 'cover', heading: '', isCover: true,
        blocks: [{
          type: 'cover',
          header: 'RSUD Dr. Soetomo\nKomite Keperawatan',
          category: 'Standar Prosedur Operasional',
          judul: 'Pemasangan Infus (Intravena Kateter)',
          penyusun: [
            { label: 'Disusun',   value: 'Tim Keperawatan' },
            { label: 'Revisi',    value: '03' },
            { label: 'Berlaku',   value: '1 Agustus 2025' },
          ],
          footer: 'RSUD Dr. Soetomo\n2025',
        }],
      },

      {
        id: 'pengertian', num: '1', heading: 'Pengertian',
        keywords: ['pengertian'],
        blocks: [
          { type: 'paragraph', text: 'Pemasangan infus adalah tindakan memasukkan kateter intravena ke dalam vena perifer untuk memberikan cairan, obat, atau nutrisi secara langsung ke dalam sirkulasi darah.' },
        ],
      },

      {
        id: 'tujuan', num: '2', heading: 'Tujuan',
        keywords: ['tujuan'],
        blocks: [
          { type: 'list', items: [
            'Mempertahankan keseimbangan cairan dan elektrolit.',
            'Memberikan terapi obat intravena.',
            'Memenuhi kebutuhan nutrisi parenteral.',
            'Memfasilitasi transfusi darah.',
          ]},
        ],
      },

      {
        id: 'ruang-lingkup', num: '3', heading: 'Ruang Lingkup & Kebijakan',
        keywords: ['kebijakan', 'legal'],
        blocks: [
          { type: 'list', items: [
            'Berlaku di seluruh unit rawat inap, IGD, dan kamar operasi.',
            'Dilakukan oleh perawat dengan kompetensi minimal PK II.',
            'Wajib menggunakan prinsip aseptik & hand hygiene 6 langkah WHO.',
          ]},
          { type: 'callout', icon: 'shield-alert', variant: 'warning', text: 'Perawat wajib memahami aspek legal: kesalahan prosedur dapat berimplikasi malpraktik sesuai UU No. 38/2014.' },
        ],
      },

      {
        id: 'alat', num: '4', heading: 'Alat & Bahan',
        keywords: ['alat', 'bahan'],
        blocks: [
          { type: 'table',
            headers: ['No', 'Alat/Bahan', 'Jumlah', 'Keterangan'],
            rows: [
              ['1', 'Set infus (abocath) sesuai ukuran', '1 set', 'No. 20G/22G/24G'],
              ['2', 'Cairan infus sesuai order', '1 botol', 'Cek tanggal & kejernihan'],
              ['3', 'Infus set / tubing', '1 set', '—'],
              ['4', 'Kapas alkohol / alcohol swab', '3 buah', '—'],
              ['5', 'Handscoon steril', '1 pasang', '—'],
              ['6', 'Plester & kasa steril', 'secukupnya', 'Fiksasi'],
              ['7', 'Tourniquet', '1 buah', '—'],
              ['8', 'Label infus & spidol', '1 set', 'Tanggal, jam, inisial'],
            ],
          },
        ],
      },

      {
        id: 'prosedur', num: '5', heading: 'Prosedur Pelaksanaan',
        keywords: ['prosedur', 'langkah kerja'],
        blocks: [
          { type: 'section', num: 'A', heading: 'Persiapan' },
          { type: 'table',
            headers: ['No', 'Langkah', 'Rasional'],
            rows: [
              ['1', 'Verifikasi identitas pasien & order dokter', 'Memenuhi 5 benar & mencegah kesalahan pasien'],
              ['2', 'Cuci tangan 6 langkah', 'Mencegah infeksi nosokomial'],
              ['3', 'Siapkan alat di meja tindakan, cek keutuhan kemasan & kadaluarsa', 'Menjamin sterilitas & keamanan bahan'],
              ['4', 'Jelaskan prosedur & tujuan pada pasien', 'Mendapatkan informed consent & mengurangi ansietas'],
            ],
          },

          { type: 'section', num: 'B', heading: 'Pelaksanaan' },
          { type: 'table',
            headers: ['No', 'Langkah', 'Rasional'],
            rows: [
              ['1', 'Pasang tourniquet 10–15 cm proksimal vena', 'Mengisi vena & memudahkan visualisasi'],
              ['2', 'Pilih vena yang sesuai (elastis, tidak di area sendi)', 'Menghindari kegagalan & nyeri berulang'],
              ['3', 'Lakukan aseptik area tusukan dengan kapas alkohol', 'Desinfeksi kulit menurunkan risiko flebitis'],
              ['4', 'Tusuk abocath 15–30°, perhatikan refluks darah', 'Sudut & refluks mengonfirmasi masuk vena'],
              ['5', 'Masukkan kateter, lepas tourniquet', 'Mencegah perdarahan & hematoma'],
              ['6', 'Fiksasi dengan plester/dressing steril', 'Menjaga posisi & mencegah infeksi'],
              ['7', 'Pasang label (tanggal, jam, inisial)', 'Traceability prosedur'],
              ['8', 'Atur tetesan sesuai order, observasi kelancaran', 'Menjamin terapi sesuai program'],
            ],
          },

          { type: 'section', num: 'C', heading: 'Evaluasi & Dokumentasi' },
          { type: 'table',
            headers: ['No', 'Langkah', 'Rasional'],
            rows: [
              ['1', 'Observasi kelancaran, tanda flebitis/infiltrasi', 'Deteksi dini komplikasi'],
              ['2', 'Edukasi pasien melaporkan nyeri/bengkak', 'Partisipasi pasien dalam monitoring'],
              ['3', 'Rapikan alat & pasien', 'Kenyamanan & keselamatan'],
              ['4', 'Dokumentasi di CPPT', 'Aspek legal & kontinuitas asuhan'],
            ],
          },
        ],
      },

      {
        id: 'komplikasi', num: '6', heading: 'Komplikasi & Hal yang Perlu Diperhatikan',
        keywords: ['komplikasi'],
        blocks: [
          { type: 'table',
            headers: ['Komplikasi', 'Tanda & Gejala', 'Penanganan'],
            rows: [
              ['Flebitis', 'Merah, nyeri, hangat di area tusukan', 'Cabut infus, kompres hangat, kolaborasi antibiotik'],
              ['Hematoma', 'Bengkak, kebiruan di area tusukan', 'Kompres dingin, hentikan perdarahan'],
              ['Infiltrasi', 'Bengkak, pucat, kulit dingin', 'Hentikan infus, angkat, kompres hangat'],
              ['Tromboflebitis', 'Vena keras, kemerahan sepanjang vena', 'Cabut infus, kompres hangat, kolaborasi antikoagulan'],
            ],
          },
          { type: 'quote', text: 'Prinsip utama: bukan sekadar berhasil menusuk vena, tetapi memastikan keamanan & kenyamanan pasien sepanjang terapi.' },
        ],
      },

      {
        id: 'referensi', num: '7', heading: 'Referensi',
        keywords: ['referensi'],
        blocks: [
          { type: 'bibliography',
            items: [
              'Perry, A. G., Potter, P. A., & Ostendorf, W. R. (2020). Clinical nursing skills and techniques (10th ed.). Elsevier.',
              'Tim Pokja SIKI DPP PPNI. (2018). Standar intervensi keperawatan Indonesia (Edisi 1). DPP PPNI.',
              'World Health Organization. (2019). Guidelines on hand hygiene in health care. WHO.',
            ],
          },
        ],
      },
    ],
  },
];
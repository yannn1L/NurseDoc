/* ============================================================
   BLOCKS (DOC) — renderer Dokumen View (paper)
============================================================ */
import { esc } from '../core/dom.js';

export const docBlocks = {
    /* ---------- COVER ---------- */
    cover: {
        render: (b) => `
      <div class="doc-cover">
        ${b.header ? `<div class="doc-cover-header">${esc(b.header).replace(/\n/g,'<br>')}</div>` : ''}
        ${b.category ? `<div class="doc-cover-category">${esc(b.category)}</div>` : ''}
        <div class="doc-cover-title">${esc(b.judul)}</div>
        ${b.penyusun?.length ? `
          <div class="doc-cover-penyusun">
            <div class="doc-cover-penyusun-label">Disusun oleh:</div>
            ${b.penyusun.map(p => `
              <div class="doc-cover-penyusun-row">
                <span class="k">${esc(p.label)}</span>
                <span class="v">: ${esc(p.value)}</span>
              </div>`).join('')}
          </div>` : ''}
        ${b.footer ? `<div class="doc-cover-footer">${esc(b.footer).replace(/\n/g,'<br>')}</div>` : ''}
      </div>`,
    },
    
    /* ---------- HEADINGS ---------- */
    section: {
        render: (b) => `<h3 class="doc-section">${b.num ? `<span class="num">${esc(b.num)}.</span> ` : ''}${esc(b.heading)}</h3>`,
    },
    heading: {
        render: (b) => `<h4 class="doc-heading">${b.num ? `<span class="num">${esc(b.num)}.</span> ` : ''}${esc(b.text)}</h4>`,
    },
    subheading: {
        render: (b) => `<h4 class="doc-heading">${esc(b.text)}</h4>`,
    },
    subsubsection: {
        render: (b) => `<h5 class="doc-subsubsection">${b.num ? `<span class="num">${esc(b.num)}.</span> ` : ''}${esc(b.text)}</h5>`,
    },
    
    /* ---------- KONTEN ---------- */
    paragraph: { render: (b) => `<p class="doc-p">${esc(b.text)}</p>` },
    list: { render: (b) => `<ul class="doc-ul">${b.items.map(t=>`<li>${esc(t)}</li>`).join('')}</ul>` },
    steps: {
        render: (b) => `<ol class="doc-steps">
      ${b.items.map((s,i)=>`<li><span class="n">${i+1}.</span><span class="txt"><b>${esc(s.step)}.</b> ${esc(s.text)}</span></li>`).join('')}
    </ol>`,
    },
    
    table: {
        render: (b) => `<table class="doc-table">
      <thead><tr>${b.headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead>
      <tbody>${b.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody>
    </table>`,
    },
    
    identity: {
        render: (b) => `
      <table class="doc-identity">
        ${b.title ? `<caption>${esc(b.title)}</caption>` : ''}
        <tbody>
          ${b.fields.map(f=>`
            <tr>
              <th>${esc(f.label)}</th>
              <td>: ${esc(f.value || '—')}</td>
            </tr>`).join('')}
        </tbody>
      </table>`,
    },
    
    pathway: {
        render: (b) => `
      <div class="doc-pathway">
        ${b.title ? `<div class="pathway-title">${esc(b.title)}</div>` : ''}
        <div class="pathway-steps">
          ${b.steps.map((s, i) => `
            <div class="pathway-step ${s.highlight ? 'highlight' : ''}">${esc(s.text)}</div>
            ${i < b.steps.length - 1 ? `<div class="pathway-arrow">↓</div>` : ''}
          `).join('')}
        </div>
      </div>`,
    },
    
    bibliography: {
        render: (b) => `
      <div class="doc-bibliography">
        ${b.items.map((ref, i) => `
          <div class="bib-item">
            <span class="n">${i+1}.</span>
            <span class="ref">${esc(ref)}</span>
          </div>`).join('')}
      </div>`,
    },
    
    analysis: {
        render: (b) => `
      <div class="doc-analysis">
        <div class="analysis-head">${esc(b.title || 'Analisa')}</div>
        ${(b.items || []).map(it => `
          <div class="analysis-item">
            <div class="analysis-label">${esc(it.label)}</div>
            <div class="analysis-content">${esc(it.content)}</div>
            ${it.rationale ? `
              <div class="analysis-rationale">
                <span class="rsn-label">Rasional:</span> ${esc(it.rationale)}
              </div>` : ''}
          </div>`).join('')}
      </div>`,
    },
    
    quote: { render: (b) => `<blockquote class="doc-quote">"${esc(b.text)}"</blockquote>` },
    callout: {
        render: (b) => `<div class="doc-callout ${b.variant==='warning'?'warning':''}">
      <span style="font-weight:700;">!</span><span>${esc(b.text)}</span>
    </div>`,
    },
    diagnosa: {
        render: (b) => `<div class="doc-diagnosa">
      <div class="label">${esc(b.priority||'')}</div>
      <div class="title">${esc(b.title)}</div>
      <div class="detail">${esc(b.detail||'')}</div>
    </div>`,
    },
    soap: {
        render: (b) => `<div class="doc-soap">
      ${[['S','Subjektif',b.s],['O','Objektif',b.o],['A','Analisis',b.a],['P','Perencanaan',b.p]]
        .map(([k,l,v])=>`<div class="soap-item">
          <span class="k">${k}</span>
          <div><span class="lbl">${l}</span>${esc(v)}</div>
        </div>`).join('')}
    </div>`,
    },
};